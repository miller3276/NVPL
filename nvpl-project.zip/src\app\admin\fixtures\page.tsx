
'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { supabase } from '@/lib/supabase'

type Competition = {
  id: string
  name: string
  region: string
  season: string
  status: string
}

type Team = {
  id: string
  name: string
  abbreviation: string
  region: string
}

type Registration = {
  competition_id: string
  team_id: string
  status: string
}

type Fixture = {
  id: string
  competition_id: string
  home_team_id: string
  away_team_id: string
  matchweek: number
  kickoff_at: string
  status: string
}

export default function AdminFixturesPage() {
  const [competitions, setCompetitions] = useState<Competition[]>([])
  const [teams, setTeams] = useState<Team[]>([])
  const [registrations, setRegistrations] = useState<Registration[]>([])
  const [fixtures, setFixtures] = useState<Fixture[]>([])
  const [competitionId, setCompetitionId] = useState('')
  const [homeTeamId, setHomeTeamId] = useState('')
  const [awayTeamId, setAwayTeamId] = useState('')
  const [matchweek, setMatchweek] = useState('1')
  const [kickoff, setKickoff] = useState('')
  const [loading, setLoading] = useState(true)
  const [busy, setBusy] = useState(false)
  const [message, setMessage] = useState('')

  async function loadData() {
    setLoading(true)

    const [competitionResult, teamResult, registrationResult, fixtureResult] =
      await Promise.all([
        supabase
          .from('competitions')
          .select('id, name, region, season, status')
          .in('status', ['upcoming', 'active'])
          .order('name'),
        supabase
          .from('teams')
          .select('id, name, abbreviation, region')
          .order('name'),
        supabase
          .from('competition_team_registrations')
          .select('competition_id, team_id, status')
          .eq('status', 'registered'),
        supabase
          .from('nvpl_fixtures')
          .select('id, competition_id, home_team_id, away_team_id, matchweek, kickoff_at, status')
          .order('kickoff_at')
      ])

    if (competitionResult.error || teamResult.error ||
        registrationResult.error || fixtureResult.error) {
      setMessage(
        competitionResult.error?.message ||
        teamResult.error?.message ||
        registrationResult.error?.message ||
        fixtureResult.error?.message ||
        'Could not load fixture information.'
      )
    } else {
      setCompetitions(competitionResult.data || [])
      setTeams(teamResult.data || [])
      setRegistrations(registrationResult.data || [])
      setFixtures(fixtureResult.data || [])
    }

    setLoading(false)
  }

  useEffect(() => {
    loadData()
  }, [])

  const eligibleTeams = teams.filter(team =>
    registrations.some(registration =>
      registration.competition_id === competitionId &&
      registration.team_id === team.id &&
      registration.status === 'registered'
    )
  )

  function teamName(id: string) {
    const team = teams.find(item => item.id === id)
    return team ? `${team.name} (${team.abbreviation})` : 'Unknown club'
  }

  function competitionName(id: string) {
    return competitions.find(item => item.id === id)?.name || 'Competition'
  }

  async function createFixture(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setBusy(true)
    setMessage('')

    const { error } = await supabase.rpc('create_nvpl_fixture', {
      p_competition_id: competitionId,
      p_home_team_id: homeTeamId,
      p_away_team_id: awayTeamId,
      p_matchweek: Number(matchweek),
      p_kickoff_at: new Date(kickoff).toISOString()
    })

    if (error) {
      setMessage(error.message)
    } else {
      setMessage('Fixture scheduled successfully.')
      setHomeTeamId('')
      setAwayTeamId('')
      setKickoff('')
      await loadData()
    }

    setBusy(false)
  }

  return (
    <main className="min-h-screen bg-[#080b14] text-white px-5 py-10">
      <div className="max-w-6xl mx-auto">
        <Link href="/dashboard" className="text-sm text-gray-400 hover:text-white">
          ← Back to dashboard
        </Link>

        <div className="mt-8 mb-8">
          <p className="text-sm tracking-[0.25em] text-blue-400 font-semibold">
            NVPL ADMINISTRATION
          </p>
          <h1 className="text-4xl font-bold mt-2">Fixture scheduler</h1>
          <p className="text-gray-400 mt-2">
            Schedule matches between registered clubs.
          </p>
        </div>

        {message && (
          <div className="mb-6 rounded-xl border border-blue-500/30 bg-blue-500/10 p-4 text-sm">
            {message}
          </div>
        )}

        {loading ? (
          <p className="text-gray-400">Loading fixtures...</p>
        ) : (
          <>
            <form
              onSubmit={createFixture}
              className="rounded-2xl border border-white/10 bg-white/[0.04] p-6 mb-10 space-y-5"
            >
              <h2 className="text-2xl font-bold">Schedule a fixture</h2>

              <div>
                <label className="block text-sm text-gray-300 mb-2">
                  Competition
                </label>
                <select
                  required
                  value={competitionId}
                  onChange={event => {
                    setCompetitionId(event.target.value)
                    setHomeTeamId('')
                    setAwayTeamId('')
                  }}
                  className="w-full rounded-lg border border-white/10 bg-[#111827] p-3"
                >
                  <option value="">Select competition</option>
                  {competitions.map(competition => (
                    <option key={competition.id} value={competition.id}>
                      {competition.name} — {competition.region} — {competition.season}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm text-gray-300 mb-2">
                    Home club
                  </label>
                  <select
                    required
                    value={homeTeamId}
                    onChange={event => setHomeTeamId(event.target.value)}
                    className="w-full rounded-lg border border-white/10 bg-[#111827] p-3"
                  >
                    <option value="">Select home club</option>
                    {eligibleTeams.map(team => (
                      <option key={team.id} value={team.id}>
                        {team.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm text-gray-300 mb-2">
                    Away club
                  </label>
                  <select
                    required
                    value={awayTeamId}
                    onChange={event => setAwayTeamId(event.target.value)}
                    className="w-full rounded-lg border border-white/10 bg-[#111827] p-3"
                  >
                    <option value="">Select away club</option>
                    {eligibleTeams
                      .filter(team => team.id !== homeTeamId)
                      .map(team => (
                        <option key={team.id} value={team.id}>
                          {team.name}
                        </option>
                      ))}
                  </select>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm text-gray-300 mb-2">
                    Matchweek
                  </label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={matchweek}
                    onChange={event => setMatchweek(event.target.value)}
                    className="w-full rounded-lg border border-white/10 bg-[#111827] p-3"
                  />
                </div>

                <div>
                  <label className="block text-sm text-gray-300 mb-2">
                    Kickoff date and time
                  </label>
                  <input
                    type="datetime-local"
                    required
                    value={kickoff}
                    onChange={event => setKickoff(event.target.value)}
                    className="w-full rounded-lg border border-white/10 bg-[#111827] p-3"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={busy || !competitionId || !homeTeamId || !awayTeamId || !kickoff}
                className="rounded-lg bg-blue-600 px-6 py-3 font-semibold hover:bg-blue-500 disabled:opacity-50"
              >
                {busy ? 'Scheduling...' : 'Create fixture'}
              </button>
            </form>

            <section>
              <h2 className="text-2xl font-bold mb-4">Scheduled fixtures</h2>

              {fixtures.length === 0 ? (
                <p className="text-gray-400">No fixtures have been scheduled yet.</p>
              ) : (
                <div className="space-y-3">
                  {fixtures.map(fixture => (
                    <div
                      key={fixture.id}
                      className="rounded-xl border border-white/10 bg-white/[0.03] p-5"
                    >
                      <p className="text-xs text-blue-400 mb-2">
                        {competitionName(fixture.competition_id)} · Matchweek {fixture.matchweek}
                      </p>
                      <div className="flex flex-wrap items-center justify-between gap-3">
                        <p className="font-semibold">
                          {teamName(fixture.home_team_id)}
                          <span className="text-gray-500 mx-3">vs</span>
                          {teamName(fixture.away_team_id)}
                        </p>
                        <span className="text-sm text-gray-400">
                          {new Date(fixture.kickoff_at).toLocaleString('en-AU')}
                        </span>
                      </div>
                      <p className="text-xs text-gray-500 mt-2">
                        {fixture.status.toUpperCase()}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </section>
          </>
        )}
      </div>
    </main>
  )
}
