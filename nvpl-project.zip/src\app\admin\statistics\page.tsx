
'use client'

import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'

type Fixture = {
  id: string
  competition_id: string
  home_team_id: string
  away_team_id: string
  status: string
}

type Team = {
  id: string
  name: string
}

type Player = {
  id: string
  username: string
  gamertag: string
}

export default function AdminStatisticsPage() {
  const [fixtures, setFixtures] = useState<Fixture[]>([])
  const [teams, setTeams] = useState<Team[]>([])
  const [players, setPlayers] = useState<Player[]>([])
  const [fixtureId, setFixtureId] = useState('')
  const [teamId, setTeamId] = useState('')
  const [playerId, setPlayerId] = useState('')
  const [message, setMessage] = useState('')
  const [busy, setBusy] = useState(false)

  const [goals, setGoals] = useState('0')
  const [assists, setAssists] = useState('0')
  const [shots, setShots] = useState('0')
  const [shotsOnTarget, setShotsOnTarget] = useState('0')
  const [saves, setSaves] = useState('0')
  const [cleanSheet, setCleanSheet] = useState(false)
  const [passesCompleted, setPassesCompleted] = useState('0')
  const [passesAttempted, setPassesAttempted] = useState('0')
  const [minutesPlayed, setMinutesPlayed] = useState('90')

  useEffect(() => {
    async function load() {
      const [fixtureResult, teamResult, playerResult] = await Promise.all([
        supabase.from('nvpl_fixtures')
          .select('id,competition_id,home_team_id,away_team_id,status')
          .order('created_at', { ascending: false }),
        supabase.from('teams').select('id,name').order('name'),
        supabase.from('player_profiles')
          .select('id,username,gamertag')
          .order('username')
      ])

      if (fixtureResult.error || teamResult.error || playerResult.error) {
        setMessage(
          fixtureResult.error?.message ||
          teamResult.error?.message ||
          playerResult.error?.message ||
          'Could not load data'
        )
        return
      }

      setFixtures(fixtureResult.data || [])
      setTeams(teamResult.data || [])
      setPlayers(playerResult.data || [])
    }

    load()
  }, [])

  const selectedFixture = fixtures.find(f => f.id === fixtureId)

  const availableTeams = selectedFixture
    ? teams.filter(t =>
        t.id === selectedFixture.home_team_id ||
        t.id === selectedFixture.away_team_id
      )
    : []

  async function savePlayerStats() {
    if (!fixtureId || !teamId || !playerId) {
      setMessage('Choose a fixture, team and player.')
      return
    }

    const values = [
      goals, assists, shots, shotsOnTarget, saves,
      passesCompleted, passesAttempted, minutesPlayed
    ].map(Number)

    if (values.some(value => !Number.isInteger(value) || value < 0)) {
      setMessage('All statistics must be non-negative whole numbers.')
      return
    }

    if (Number(shotsOnTarget) > Number(shots)) {
      setMessage('Shots on target cannot exceed shots.')
      return
    }

    if (Number(passesCompleted) > Number(passesAttempted)) {
      setMessage('Completed passes cannot exceed attempted passes.')
      return
    }

    setBusy(true)
    setMessage('Saving player statistics...')

    const { error } = await supabase.rpc('nvpl_save_player_match_stats', {
      p_fixture_id: fixtureId,
      p_player_id: playerId,
      p_team_id: teamId,
      p_goals: Number(goals),
      p_assists: Number(assists),
      p_shots: Number(shots),
      p_shots_on_target: Number(shotsOnTarget),
      p_saves: Number(saves),
      p_clean_sheet: cleanSheet,
      p_passes_completed: Number(passesCompleted),
      p_passes_attempted: Number(passesAttempted),
      p_minutes_played: Number(minutesPlayed)
    })

    setBusy(false)
    setMessage(error ? error.message : 'Player statistics saved.')
  }

  const inputClass =
    'w-full rounded-lg border border-slate-700 bg-slate-800 p-3 text-white'

  return (
    <main className="min-h-screen bg-slate-950 p-6 text-white">
      <div className="mx-auto max-w-4xl space-y-6">
        <header>
          <h1 className="text-3xl font-black">Statistics Manager</h1>
          <p className="text-slate-400">
            Record individual player match performances.
          </p>
        </header>

        <section className="space-y-4 rounded-xl bg-slate-900 p-5">
          <div>
            <label className="mb-2 block text-sm">Fixture</label>
            <select
              className={inputClass}
              value={fixtureId}
              onChange={e => {
                setFixtureId(e.target.value)
                setTeamId('')
              }}
            >
              <option value="">Choose fixture</option>
              {fixtures.map(f => (
                <option key={f.id} value={f.id}>
                  {teams.find(t => t.id === f.home_team_id)?.name || 'Home'}
                  {' vs '}
                  {teams.find(t => t.id === f.away_team_id)?.name || 'Away'}
                  {' — '}
                  {f.status}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="mb-2 block text-sm">Team</label>
            <select
              className={inputClass}
              value={teamId}
              onChange={e => setTeamId(e.target.value)}
              disabled={!fixtureId}
            >
              <option value="">Choose team</option>
              {availableTeams.map(t => (
                <option key={t.id} value={t.id}>{t.name}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="mb-2 block text-sm">Player</label>
            <select
              className={inputClass}
              value={playerId}
              onChange={e => setPlayerId(e.target.value)}
            >
              <option value="">Choose player</option>
              {players.map(p => (
                <option key={p.id} value={p.id}>
                  {p.gamertag || p.username} (@{p.username})
                </option>
              ))}
            </select>
          </div>
        </section>

        <section className="rounded-xl bg-slate-900 p-5">
          <h2 className="mb-4 text-xl font-bold">Player performance</h2>

          <div className="grid gap-4 sm:grid-cols-2">
            {[
              ['Goals', goals, setGoals],
              ['Assists', assists, setAssists],
              ['Shots', shots, setShots],
              ['Shots on target', shotsOnTarget, setShotsOnTarget],
              ['Goalkeeper saves', saves, setSaves],
              ['Passes completed', passesCompleted, setPassesCompleted],
              ['Passes attempted', passesAttempted, setPassesAttempted],
              ['Minutes played', minutesPlayed, setMinutesPlayed]
            ].map(([label, value, setter]) => (
              <label key={label as string} className="block">
                <span className="mb-2 block text-sm text-slate-300">
                  {label as string}
                </span>
                <input
                  type="number"
                  min="0"
                  className={inputClass}
                  value={value as string}
                  onChange={e =>
                    (setter as (value: string) => void)(e.target.value)
                  }
                />
              </label>
            ))}
          </div>

          <label className="mt-5 flex items-center gap-3">
            <input
              type="checkbox"
              checked={cleanSheet}
              onChange={e => setCleanSheet(e.target.checked)}
              className="h-4 w-4"
            />
            Clean sheet
          </label>

          <button
            onClick={savePlayerStats}
            disabled={busy}
            className="mt-6 w-full rounded-lg bg-blue-600 p-3 font-bold disabled:opacity-50"
          >
            {busy ? 'Saving...' : 'Save player statistics'}
          </button>

          {message && (
            <p className="mt-4 text-sm text-amber-300">{message}</p>
          )}
        </section>
      </div>
    </main>
  )
}
